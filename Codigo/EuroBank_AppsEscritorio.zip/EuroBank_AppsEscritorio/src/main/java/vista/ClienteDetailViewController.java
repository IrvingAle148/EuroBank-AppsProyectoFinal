package vista;

public class ClienteDetailViewController {
}
