package vista;

public class CuentasGestionViewController {
}
