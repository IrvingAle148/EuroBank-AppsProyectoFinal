package vista;

public class CuentasViewController {
}
