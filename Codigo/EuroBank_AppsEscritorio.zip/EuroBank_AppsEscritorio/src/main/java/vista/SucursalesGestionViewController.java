package vista;

public class SucursalesGestionViewController {
}
