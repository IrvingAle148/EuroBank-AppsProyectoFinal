package modelo.excepciones;

public class ElementoDuplicadoException extends Exception {
    public ElementoDuplicadoException(String mensaje) {
        super(mensaje);
    }
}
